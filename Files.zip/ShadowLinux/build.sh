#!/usr/bin/env bash
set -e

echo "=== ShadowLinux ISO Builder (Ubuntu 24.04 KDE) ==="

WORKDIR="$PWD/build"
sudo rm -rf "$WORKDIR"
mkdir -p "$WORKDIR"

# Bootstrap minimal Ubuntu 24.04
sudo debootstrap --arch=amd64 noble "$WORKDIR/chroot" http://archive.ubuntu.com/ubuntu/

# Basic setup inside chroot
sudo mount --bind /dev "$WORKDIR/chroot/dev"
sudo mount -t proc none "$WORKDIR/chroot/proc"
sudo mount --bind /sys "$WORKDIR/chroot/sys"
sudo cp /etc/resolv.conf "$WORKDIR/chroot/etc/"

sudo chroot "$WORKDIR/chroot" bash -c "
export DEBIAN_FRONTEND=noninteractive
apt update
apt install -y ubuntu-standard kde-standard calamares \
  steam lutris obs-studio code git python3 tor ufw \
  grub-pc-bin grub-efi-amd64-bin linux-image-generic \
  live-boot squashfs-tools xorriso

# Create live user
useradd -m -s /bin/bash ShadowUser
echo 'ShadowUser:Shadow' | chpasswd
usermod -aG sudo ShadowUser
echo 'root:Shadow' | chpasswd

# Enable firewall
ufw enable
"

# Build squashfs
mkdir -p "$WORKDIR/image/live"
sudo mksquashfs "$WORKDIR/chroot" "$WORKDIR/image/live/filesystem.squashfs" -e boot

# Copy kernel
KERNEL=$(ls "$WORKDIR/chroot/boot" | grep vmlinuz | tail -1)
INITRD=$(ls "$WORKDIR/chroot/boot" | grep initrd | tail -1)
sudo cp "$WORKDIR/chroot/boot/$KERNEL" "$WORKDIR/image/live/vmlinuz"
sudo cp "$WORKDIR/chroot/boot/$INITRD" "$WORKDIR/image/live/initrd"

# Boot config
mkdir -p "$WORKDIR/image/boot/grub"
cat <<EOF | sudo tee "$WORKDIR/image/boot/grub/grub.cfg"
set default=0
set timeout=5
menuentry "ShadowLinux Live" {
    linux /live/vmlinuz boot=live quiet splash
    initrd /live/initrd
}
EOF

# Create ISO
sudo xorriso -as mkisofs -o shadowlinux-ubuntu.iso \
  -isohybrid-gpt-basdat -J -r -V "ShadowLinux" "$WORKDIR/image"

echo "✅ Build complete. ISO: shadowlinux-ubuntu.iso"